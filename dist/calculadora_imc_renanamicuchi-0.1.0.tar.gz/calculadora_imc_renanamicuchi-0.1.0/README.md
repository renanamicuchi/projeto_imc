# Calculadora de IMC

## Descrição

Este é um pacote Python que calcula o Índice de Massa Corporal (IMC) com base no peso e altura fornecidos, classificando o resultado em categorias de peso.

## Instalação

```bash
pip install calculadora-imc